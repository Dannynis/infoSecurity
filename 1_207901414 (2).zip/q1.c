#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV EBX, %0"
        :
        : "r"(input));

    asm (
        /* Your code starts here. */
      	
        "jmp _main ;"

        //action in the edge case in the question
        "_lessThenOne:  ;"
        "  MOV EAX,0 ;"
        "jmp _END ;"

        //the function checks if the value inside EBX is a prime.
        //if EBX is not a prime then EBX = 0, or non zero value otherwise
        "_isPrime: ;"
        "MOV EDX,0;"
        "MOV ECX,2;"
        "   _firstLoop: ;"
        "   MOV EAX,EBX  ;"
        "       cmp ECX,EAX;"
        "       je _finishFirst  ;"
        "       idiv ECX ;         "
        "       cmp EDX,0 ;               "
        "       je _notPrint     ;     "
	    "	inc ECX 		;"
     	"	MOV EDX,0		;"
	    "       jmp _firstLoop          ;"
        "	_notPrint: ;"
	    "	 MOV EBX,0	;"
	    "    _finishFirst:   ;"
        "      RET            ; "

        //the main function runs from the EBX-1 to 0 searching for devisor, when one found its checks if 
        //it is prime, if so it loads it to EAX and terminates
        "_main: ;"
        "   cmp EBX,1                    ;"
        " jle _lessThenOne               ;"
        "   MOV EAX, EBX                ;"
        //increamented by 1 once in order to make prime numbers return themselfs when the input is prime
        "   inc EBX                      ;"
        "   _secondLoop:                 ;"
        "   MOV EDX,0;                   "
        "   dec EBX                     ;"
        "   cmp EBX,1                   ;"
        "   je _programEnd              ;"
        "   push EAX  ; "
        "   idiv EBX                    ;"
        "   pop EAX           ; "
       
        "   cmp EDX,0                   ;"
        "       je _checkPrime          ;"
        "   jmp _secondLoop             ;"

        " _checkPrime:                  ;"
        " push EBX                      ;"
        " push EAX                      ;"
        " CALL _isPrime                 ;"
        " cmp EBX,0                     ;"
        " pop EAX                       ;"
        " pop EBX                       ;"
        " je _secondLoop            ;"

        "_programEnd:"
        "MOV EAX,EBX                    ;"
        " _END:"
        /* Your code stops  here. */
    );

    asm ("MOV %0, EAX"
        : "=r"(output));
    printf("%d\n", output);

    
    return 0;
}
