#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV EBX, %0"
        :
        : "r"(input));

    asm (
        /* Your code starts here. */
        "MOV EAX,0; "
        "cmp EBX ,0 ;"
        "jl _END ;"
        "CALL _fibb;"
        "jmp _END ;"

        //return at end poit state
        "_returnZero: ;"
        "  MOV EAX,0  ;"
        "  jmp _funcEnd ;"

        "_returnOne: ;"
        "  MOV EAX,1  ;"
        "  jmp _funcEnd ;"

        //the end poit of the recursion
        "_fibb: ;"
        "cmp EBX,0  ;"
        "je _returnZero ;"
        "cmp EBX,1  ;" 
        "je _returnOne  ;"

        "dec  EBX       ;"

       ////////Prolog////////////
        "push EBX       ;"
        "push ECX       ;"
       ////////Prolog_END////////

        "CALL _fibb     ;"

       ////////Epilog////////////
        "pop ECX       ;"
        "pop EBX       ;"
       ////////Epilog_END////////

        "MOV ECX,EAX    ;"
        "dec EBX        ;"

       ////////Prolog////////////
        "push EBX       ;"
        "push ECX       ;"
       ////////Prolog_END////////

        "CALL _fibb     ;"
      
       ////////Epilog////////////
        "pop ECX       ;"
        "pop EBX       ;"
       ////////Epilog_END////////
         // the point where an = a(n-1) + a(n-2) 
        "add EAX,ECX    ;"
        "_funcEnd:      ;"
        "   RET         ;"

        "_END:"

        /* Your code stops  here. */
    );

    asm ("MOV %0, EAX"
        : "=r"(output));

    printf("%d\n", output);
    
    return 0;
}
