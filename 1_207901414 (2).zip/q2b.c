#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV EBX, %0"
        :
        : "r"(input));

    asm (
        
        /* Your code starts here. */
        
        "MOV EAX,0   ;"

        "cmp EBX,0   ;"
        "jle _end     ;"

        
        "MOV EDX,1   ;"
        "jmp _second ;"
        "_loop:      ;"

        //check if we reached the desired value
        "cmp EBX,0   ;"
        "je _endD    ;"
        "add EAX,EDX ;"
        "DEC EBX     ;"

        "cmp EBX,0   ;"
        "je _end     ;"        

        "_second:    ;"

        "add EDX,EAX ;"
        // the point where an = a(n-1) + a(n-2) 
        "DEC EBX     ;"

        "jmp _loop   ;"

        "_endD:      ;"
        "MOV EAX,EDX ;"

        "_end:"



        /* Your code stops  here. */


    );

    asm ("MOV %0, EAX"
        : "=r"(output));

    printf("%d\n", output);
    
    return 0;
}
