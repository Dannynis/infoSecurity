#!/usr/bin/python




def main():
	print "asd"