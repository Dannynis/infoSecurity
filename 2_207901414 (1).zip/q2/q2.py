def patch_program(path):
    with open(path, 'rb') as reader:
        data = reader.read()
        import assemble
        
        #inserting patch1
        data = bytearray(data)
        offset = 0x633
        replace = assemble.assemble_file("patch1.asm")

        #keeping the rest of the code the same
        data = data[0:offset]+ replace + data[offset+len(replace):]


        #inserting patch1
        offset = 0x5cd
        replace = assemble.assemble_file("patch2.asm")

        #keeping the rest of the code the same
        data = data[0:offset]+ replace + data[offset+len(replace):]



    with open(path + '.patched', 'wb') as writer:
        writer.write(data)


def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <readfile-program>'.format(argv[0]))
        return -1
    path = argv[1]
    patch_program(path)
    print('done')


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
