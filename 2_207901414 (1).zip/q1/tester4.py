import subprocess
import os
import glob


FOLDER = os.getcwd()
FIND_FILE = os.path.join(FOLDER,'*.msg')
file_list = glob.iglob(FIND_FILE)

failed = []
for filename in sorted(file_list):

    ret="valid message\n"
    p = subprocess.Popen(["./msgcheck.patched", filename], stdout=subprocess.PIPE)
    value_p, err  = p.communicate()

    if(value_p == ret):
        print filename + " PASS" 
        continue
    print filename + " ###FAIL###"
    failed.append(os.path.basename(filename))

print ""

