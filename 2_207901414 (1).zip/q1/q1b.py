def fix_message(path):
    with open(path, 'rb') as reader:
        data = reader.read()
        ldata = list(data)
        #empty message or message with only one char or only two chars
        if(len(data)==0 or len(data)==1 or len(data)==2):
        	ldata=["x","W"]
        	ldata[0]=chr(0)
      
        else:
        	initialXor ="W"
	        #checking if there is length overflow at first parameter
	        if (ord(data[0])>len(data)-2):
	        	ldata[0]=chr(0)
	        #the actual xor value of the bytes computed here
	        for i in range (2,ord(ldata[0])+2):
	            initialXor = ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(initialXor,ldata[i]))
	        #inserting the actual xor byte insead of the expected one
	        ldata[1]=initialXor
        data= ''.join(ldata)

    with open(path + '.fixed', 'wb') as writer:
        writer.write(data)


def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <msg-file>'.format(argv[0]))
        return -1
    path = argv[1]
    fix_message(path)
    print('done')


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
