import subprocess
import q1a
import os
import glob


FOLDER = os.getcwd()
FIND_FILE = os.path.join(FOLDER,'*.msg')
file_list = glob.iglob(FIND_FILE)

failed = []
for filename in sorted(file_list):

    ret="invalid message\n"
    if(q1a.check_message(filename)):
        ret="valid message\n"
    p = subprocess.Popen(["./msgcheck", filename], stdout=subprocess.PIPE)
    value_p, err  = p.communicate()

    if(value_p == ret):
        print filename + " PASS" 
        continue
    print filename + " ###FAIL###"
    failed.append(os.path.basename(filename))

print ""
print "q1a.py and msgcheck disagree on:"
print failed

ok = []
for ff in failed:
    with open(ff, "rb") as ff2:
        msg = ff2.read()
        if msg[0] > len(msg) - 2:
            ok.append(ff)

print ""
print "these failed because msg[0] > len-2, so it's ok:"
print ok
print ""
print "so the REALLY FAILED ones are:"
l_fin = [item for item in failed if item not in ok]
print l_fin
print ""

if (l_fin == []):
    print "GOOD JOB BEN!"
else:
    print "YOU NAUGHTY, go pray to Gittik!!"
