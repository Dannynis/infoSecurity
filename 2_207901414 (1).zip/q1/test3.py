import subprocess
import q1c as q1b
import glob
import os

FOLDER = os.getcwd()
FIND_FILE = os.path.join(FOLDER,'*.msg')
file_list = glob.iglob(FIND_FILE)
failed = []
for filename in sorted(file_list):
    filename = os.path.basename(filename)

    q1b.fix_message(filename)
    filename += ".fixed"

    ret = "valid message"

    p = subprocess.Popen(["./msgcheck", filename], stdout=subprocess.PIPE)
    value_p, err  = p.communicate()

    value_p = value_p.strip('\n')

    if(value_p == ret):
        print filename + " PASS" 
        continue
    print filename + " ###FAIL###"
    failed.append(filename)

print ""
print failed
if (failed == []):
    print "GOOD JOB BEN!"
else:
    print "YOU NAUGHTY, go pray to Gittik!!"

