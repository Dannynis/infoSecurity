mac = 0x47
lst = []

# len 0
lst.append('')
#print lst

# len 1
lst.append(chr(0))
lst.append(chr(1))
lst.append(chr(2))
lst.append(chr(3))
lst.append(chr(0xFF))
#print lst

# len 2
for i in range(len(lst)):
	lst.append(lst[i] + chr(mac))
	lst.append(lst[i] + chr(0))
#print lst

# len 3+
for i in range(len(lst)):
	lst.append(lst[i] + chr(mac))
	lst.append(str(lst[i]) + chr(0))

print lst

for i in range(len(lst)):
	with open(str(11 + i) + ".msg", "wb") as f:
		f.write(lst[i])

# special case for q1:
macc = 0xCD
for i in range(0x7E, 0xFF + 1):
	lenn = i;

	with open('_' + str(i) + ".msg", "wb") as f2:
		textt = chr(lenn) + '\x00' + chr(macc) + chr(0x00)*(lenn-1)
		f2.write(textt)

