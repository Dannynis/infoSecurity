import subprocess
import os
import glob


FOLDER = os.getcwd()
FIND_FILE = os.path.join(FOLDER,'*.msg')
file_list = glob.iglob(FIND_FILE)

failed = []
for filename in sorted(file_list):


    p = subprocess.Popen(["./msgcheck.patched", filename], stdout=subprocess.PIPE)
    value_p, err  = p.communicate()
    
    ret="valid message\n"
    p1 = subprocess.Popen(["./msgcheck", filename], stdout=subprocess.PIPE)
    value_p1, err  = p1.communicate()

    q = subprocess.call(["echo", "$?"])
    
    value_p1= value_p1.strip()
    value_p = value_p.strip()

    if(q == 0 and value_p1 == value_p):
        print filename + " PASS" 
        continue
  
    print filename + " ###FAIL###"
    failed.append(os.path.basename(filename))

print ""
print failed
