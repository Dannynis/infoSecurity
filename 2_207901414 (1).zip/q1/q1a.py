def check_message(path):
    fo = open(path, "r")
    firstByte = fo.read(1)
    secondByte = fo.read(1) 
    initialXor ="W" #the char at the second place
    loopRun =0 
    while(len(firstByte)!=0 and loopRun < ord(firstByte)):
    	loopRun=loopRun+1
    	token = fo.read(1)
        #the xor of the bytes till the marked place computed here
    	initialXor = ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(initialXor,token))
    if(initialXor == secondByte):
    	return 1
    return 0

def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <msg-file>'.format(argv[0]))
        return -1
    path = argv[1]
    if check_message(path):
        print('valid message')
        return 0
    else:
        print('invalid message')
        return 1


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
