import assemble
import string
import sys

GENERAL_REGISTERS = [
    'eax', 'ebx', 'ecx', 'edx', 'esi', 'edi'
]


ALL_REGISTERS = GENERAL_REGISTERS + [
    'esp', 'eip', 'ebp'
]




class GadgetSearch(object):
    def __init__(self, dump_path, start_addr):
        """
        Construct the GadgetSearch object.

        Input:
            dump_path: The path to the memory dump file created with GDB.
            start_addr: The starting memory address of this dump.
        """
        self.dump_path = dump_path
        self.start_addr = start_addr



    def get_format_count(self, gadget_format):
        """
        Get how many different register placeholders are in the pattern.
        
        Examples:
            self.get_format_count('POP ebx')
            => 0
            self.get_format_count('POP {0}')
            => 1
            self.get_format_count('XOR {0}, {0}; ADD {0}, {1}')
            => 2
        """
        # Hint: Use the string.Formatter().parse method:
        import string
        count = 0
        counted = []
        for x in string.Formatter().parse(gadget_format):
            if x[1] != None and x[1] not in counted:
                count = count +1
                counted.append(x[1])
        return count


    def get_register_combos(self, nregs, registers):
        """
        Return all the combinations of `registers` with `nregs` registers in
        each combination. Duplicates ARE allowed!

        Example:
            self.get_register_combos(2, ('eax', 'ebx'))
            => [['eax', 'eax'],
                ['eax', 'ebx'],
                ['ebx', 'eax'],
                ['ebx', 'ebx']]
        """

        import itertools
        return list(itertools.product(registers, repeat=nregs))


        



    def format_all_gadgets(self, gadget_format, registers):
        """
        Format all the possible gadgets for this format with the given
        registers.

        Example:
            self.format_all_gadgets("POP {0}; ADD {0}, {1}", ('eax', 'ecx'))
            => ['POP eax; ADD eax, eax',
                'POP eax; ADD eax, ecx',
                'POP ecx; ADD ecx, eax',
                'POP ecx; ADD ecx, ecx']
        """
        # Hints:
        # 1. Use the format function:
        #    'Hi {0}! I am {1}, you are {0}'.format('Luke', 'Vader')
        #    => 'Hi Luke! I am Vader, you are Luke'
        # 2. You can use an array instead of specifying each argument. Use the
        #    internet, the force is strong with StackOverflow.
        nregs = self.get_format_count(gadget_format)
        combList = self.get_register_combos(nregs,registers)
        gadgetList = []
        #print combList
        for comb in combList:
            #print comb
            gadgetList.append(gadget_format.format(*comb))
      
        #print gadgetList
        return gadgetList


    def find_all(self, gadget):
        """
        Return all the addresses of the gadget inside the memory dump.

        Example:
            self.find_all('POP eax')
            => < all ABSOLUTE addresses in memory of 'POP eax; RET' >
        """
        # Notes:
        # 1. Addresses are ABSOLUTE (for example, 0x08403214), NOT RELATIVE to the
        #    beginning of the file (for example, 12).
        # 2. Don't forget to add the 'RET'
        
        toSearch = gadget + '; RET'
        asmToSearch = assemble.assemble_data(toSearch)
        text = open(self.dump_path,'r').read()
        

        start=0
        offsets = []
        hexAddr = []
        while (start<len(text)):
            index = text.find(asmToSearch,start,len(text))
            if index == -1 :
                break
            offsets.append(index)
            start = index + len(asmToSearch)

        for offset in offsets:
            hexAddr.append(hex(offset+ self.start_addr)[:-1])
        #print hexAddr
        return hexAddr


    def find(self, gadget, condition=None):
        """
        Return the first result of find_all. If condition is specified, only
        consider addresses that meet the condition.
        """
        condition = condition or (lambda x: True)
        try:
            return next(addr for addr in self.find_all(gadget) if condition(addr))
        except StopIteration:
            raise ValueError("Couldn't find matching address for " + gadget)

    def find_all_formats(self, gadget_format, registers=GENERAL_REGISTERS):
        """
        Similar to find_all - but return all the addresses of all
        possible gadgets that can be created with this format and registers.
        Every elemnt in the result will be a tuple of the gadget string and
        the address in which it appears.

        Example:
            self.find_all_formats('POP {0}; POP {1}')
            => [('POP eax; POP ebx', address1),
                ('POP ecx; POP esi', address2),
                ...]
        """
        gadgetAdresses = []
        allCombs = self.format_all_gadgets(gadget_format,registers)
        for comb in allCombs:
            for address in self.find_all(comb):
                gadgetAdresses.append((comb,address))

        #print gadgetAdresses
        return gadgetAdresses
        

    def find_format(self, gadget_format, registers=GENERAL_REGISTERS, condition=None):
        """
        Return the first result of find_all_formats. If condition is specified,
        only consider addresses that meet the condition.
        """
        condition = condition or (lambda x: True)
        try:
            return next(
                addr for addr in self.find_all_formats(gadget_format, registers)
                if condition(addr))
        except StopIteration:
            raise ValueError(
 

                "Couldn't find matching address for " + gadget_format)



def main(argv):
    a= GadgetSearch("libc.bin",0xb7c39750)
    #a.get_register_combos(3, ('eax', 'ebx','ecx'))
 
    #a.get_format_count(argv[1])

    #a.format_all_gadgets("POP {0}; ADD {0}, {1}", ('eax', 'ecx'))

    #a.find_all('pop eax')

    #a.find_all_formats('POP {0}; POP {1}')
    print a.find_format(argv)

if __name__ == '__main__':
    main(sys.argv[1])





