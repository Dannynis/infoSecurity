from scapy.all import *
import string,math

unpersons = set()



def spy(packet):
    
    if TCP in packet   :
    	ip = packet.getlayer(IP)
        tcp = packet.getlayer(TCP)
        
        payload= tcp.payload

        #if the packet is TCP and has payload, then the string 'love' is searched in it

        
        if len(tcp.payload) != 0 and 'love' in str(payload)  :
        	
            unpersons.add(ip.src)
            #print ("COUGHT")


      


def main():
    sniff(prn=spy)


if __name__ == '__main__':
    main()
