import socket
from Crypto.Cipher import AES
from Crypto import Random

#the iv and the key are 16 chars long and pre shared between julia and winston

KEY= "fedcba9876543210"
IV = "0123456789abcdef"


def enc_AES(massege):

    #calculating the padding that the massege would need, we assume that the last byte of the massage resamble its size
    #bounded by 256 long masseges

	to_pad = 16 - (len(massege)+1) % 16

    #the padding would be random chars

	rnd = Random.new().read(to_pad)

    #the plain text is the massege with the random padding and the length at the end

	plainText= massege + rnd + chr(len(massege))

	encryptor = AES.new(KEY, AES.MODE_CBC, IV)

	return encryptor.encrypt(plainText)



def send_message(ip, port):
    # Reimplement me! (b1)
    connection = socket.socket()
    try:
        connection.connect((ip, port))
        #sebds the encrypted massege
        connection.send( ('I love you') )


    finally:
        connection.close()


def main():
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
