import socket

from Crypto.Cipher import AES
from Crypto import Random

#the iv and the key are 16 chars long and pre shared between julia and winston
KEY= "fedcba9876543210"
IV = "0123456789abcdef"

def dec_AES(massege):
    
    #the decryption is similar to the encryption  

    decryptor = AES.new(KEY, AES.MODE_CBC, IV)

    plainText = decryptor.decrypt(massege)

    #the last byte of the decrypted massege is used to determine the size of the original massege

    dec= plainText[:ord(plainText[-1])]

    return dec

def receive_message(port):
    # Reimplement me! (a2)
    listener = socket.socket()
    try:
        listener.bind(('', port))
        listener.listen(1)
        connection, address = listener.accept()
        try:
            recv= connection.recv(1024)
            return (dec_AES(recv))
        finally:
            connection.close()
    finally:
        listener.close()


def main():
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
