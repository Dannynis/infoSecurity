
import math


def main(args):

	string = args[1]
   	
   	print string

	distribution = [float(string.count(c)) / len(string) for c in set(string)]
	entropy = -sum(p * math.log(p)/math.log(2.0) for p in distribution)

	print entropy


if __name__ == '__main__':
    import sys
    main(sys.argv)
