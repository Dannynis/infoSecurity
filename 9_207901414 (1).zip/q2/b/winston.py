from scapy.all import *

#taken from https://stackoverflow.com/questions/10237926/convert-string-to-list-of-bits-and-viceversa
#the function takes string ang converts it to string of bits
def tobits(s):
    result = ''
    for c in s:
        bits = bin(ord(c))[2:]
        bits = '00000000'[len(bits):] + bits
        result= result + bits
    return result


def send_message(ip, port):

		massege = 'I love you' 

		bits = tobits(massege)

		#print bits + " "+ str(len(bits))

		#calculating the number of bits we will send in the last massege
		rem = len(bits)%3

		#calculating how many steps would it take to send the full bits string
		ToSend = int (math.ceil (float(len(bits))/3.0)) 

		print "TOsend = "+str(ToSend)

		for seq in range (0,ToSend-1):
			
			#taking every triple from the bits string and converting it to 3 bit bounded integer
			pos = seq *3 
			bitsToSend = bits[pos:pos+3]
			IntRep = int(bitsToSend,2)
			
			#print ("sending: " +bitsToSend+ " "+str(IntRep))
			#sending data through ack packet using 'reserved' to store the integer
			send( IP(dst=ip ) / TCP(sport =65000 , dport=port ,flags="A", seq=seq, ack=ToSend,reserved=IntRep))

		

		#made to send the final packet with the reminder bits
		bitsToSend = bits[-rem:]
		IntRep = int(bitsToSend,2)

		#print ("End - sending: " +bitsToSend+ " "+str(IntRep))
		send( IP(dst=ip ) / TCP(sport =65000 , dport=port ,flags="A", seq=ToSend-1, ack=ToSend,reserved=IntRep))



def main():
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
