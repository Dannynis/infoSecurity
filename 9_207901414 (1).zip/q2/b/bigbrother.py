from scapy.all import *
import string,math

unpersons = set()


#the given formula in q2

def entropy(string):

	distribution = [float(string.count(c)) / len(string) for c in set(string)]
	ent= -sum(p * math.log(p)/math.log(2.0) for p in distribution)
	return ent

def spy(packet):
     # Reimplement me! (b1)
	pay=0
	if TCP in packet   :
		ip = packet.getlayer(IP)
		tcp = packet.getlayer(TCP)

		pay= tcp.payload

		if 'love' in str(pay) :
			unpersons.add(ip.src)
			print ("Add becuase love "+ ip.src)

		#if the entropy is grater then 3 add the ip to unpersons

		elif(entropy(str(pay))>3):
			unpersons.add(ip.src)
			print ("Add because antropy "+ ip.src)


def main():
    sniff(prn=spy)


if __name__ == '__main__':
    main()
