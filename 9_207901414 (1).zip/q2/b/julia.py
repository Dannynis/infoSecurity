from scapy.all import *

our_port = 0

bits = []

receivedCounter= 0

#function to stop filtering when the all the expected packets arrived
def stopfilter(packet):

	if (len(bits)!=0 and receivedCounter==len(bits)):
		return True

	#print str(receivedCounter) + " " + str(len(bits))

	return False

#the filter filters packets that werent sent from winston to us
def packet_filter(packet):
	if(packet.haslayer('TCP') and packet['IP'].dport ==our_port and packet.sport==65000):
		#print (True)
		max_seq = packet['TCP'].seq
		return True

	return False


#the handler extracts the integer from the reserved field and stores the bits triple that represent it 
#in bins array
def handler (packet):
	
	global bits
	global receivedCounter

	tcp = packet.getlayer('TCP')
	
	parts = tcp.ack 

	seq = tcp.seq

	#initialize the array of triple bits when we discover its expected size

	if len(bits) ==0:

		bits.extend(["" for i in range(0,parts)])

	#if we discover packet that is not processed (duplicated packets arrive) we store it in the bits array

	if(bits[seq]==""):
		receivedCounter +=1

		strBin = str(bin(tcp.reserved)[2:])

		#print "str " +strBin
		
		bits[seq] = strBin

		
	#print(str(seq)+" "+str(parts))




#taken from https://stackoverflow.com/questions/10237926/convert-string-to-list-of-bits-and-viceversa
#the function takes bits string ang converts it to readble string

def frombits(bits):
    chars = []
    for b in range(len(bits) / 8):
        byte = bits[b*8:(b+1)*8]
        chars.append(chr(int(''.join([str(bit) for bit in byte]), 2)))
    return ''.join(chars)


def receive_message(port):
	global our_port 
	our_port =  port

	sniff(lfilter=packet_filter, prn=handler,stop_filter=stopfilter)

	#print bits

	outcome = ""

	#construct the original bits string from each cell in the bits array

	for BitStr in bits[:-1]:

		outcome = outcome + '000'[len(BitStr):] + BitStr

	#the final bits should be padded for the string to be dividble by 8

	rem = (8 - (len(outcome)+len(bits[-1])) % 8 )%8


	outcome = outcome + '0' *rem+ bits[-1]

	#print ("outcome: "+outcome+ " rem: "+ str(rem) )

	return frombits(outcome)

def main():
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
