from scapy.all import *


def stealth_syn_scan(ip, ports, timeout):
    
    #flags values
    FIN = 0x01
    SYN = 0x02
    RST = 0x04
    ACK = 0x10

    results = []
    for port in ports:
        p = IP(dst=ip)/TCP( dport=port, flags='S') 
       
        #send 1 syn packet and wait for respone
        resp = sr1(p, timeout=timeout) 
       

        #if no response came during the timeout, mark port as filtered
        if( resp == None  ):
            results.append('filtered')
            
        #if RST response came mark port as closed
        elif (resp.haslayer(TCP) and resp['TCP'].flags == 0x14):
            results.append('closed')

        #if SYN/ACK returned mark the port as opend
        elif (resp.haslayer(TCP) and resp['TCP'].flags == 0x12) :
            results.append('open')
            
    
       

    return results



def main(argv):
    if not 3 <= len(argv) <= 4:
        print('USAGE: %s <ip> <ports> [timeout]' % argv[0])
        return 1
    ip    = argv[1]
    ports = [int(port) for port in argv[2].split(',')]
    if len(argv) == 4:
        timeout = int(argv[3])
    else:
        timeout = 5
    results = stealth_syn_scan(ip, ports, timeout)
    for port, result in zip(ports, results):
        print('port %d is %s' % (port, result))


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
