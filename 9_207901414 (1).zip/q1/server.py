
import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

MAX = 3
PORT = 1234

sock.bind(('0.0.0.0', PORT))

sock.listen(1)
print ('Listening at', sock.getsockname())

while True:
    # Wait for a connection
    print ('waiting for a connection')
    connection, client_address = sock.accept()
