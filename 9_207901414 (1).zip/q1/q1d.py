from scapy.all import *
import socket



def on_packet(packet):
	if (packet.haslayer(TCP) and packet['TCP'].flags == 0x02):

		ip = packet.getlayer(IP)
		tcp = packet.getlayer(TCP)	

		#If SYN packet captured, we automaticly send SYN/ACK packet in response	
		resp = send (IP(dst=ip.src, src=ip.dst) / TCP(dport=tcp.sport,sport=tcp.dport, flags=0x12, seq=tcp.ack, ack=tcp.seq+len(tcp.payload))) 

		#print("sent...")





def main():
    sniff(prn=on_packet)


if __name__ == '__main__':
    main()
