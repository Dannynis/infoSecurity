from scapy.all import *
import time

blockedIPs = {}
 #In each entry there would be pair [<first received time>,<syns received in 60 seconds>]
ipsDict= {}

def on_packet(packet):

	
	#check if the packet is a TCP SYN
	if (packet.haslayer(TCP) and packet['TCP'].flags == 0x02):
		
		currentAcceptTime = time.time()
		ip = packet.getlayer(IP)
		tcp = packet.getlayer(TCP)
		#print ip.src
		IPaddr = ip.src
		
		#print (ipsDict)


		#if we already got SYN from that ip we continue the inspection
		if (IPaddr in ipsDict):
			passedTime = currentAcceptTime - ipsDict[IPaddr][0]   
			#if the last time we received the syn packet was before 60 second we clear the IP records and initialize it for the current 60 secods
			if (passedTime > 60):
				ipsDict[IPaddr][0] = currentAcceptTime
				ipsDict[IPaddr][1] = 1 
			else:
				#if the IP alredy sent more then 15 SYNs we block it
				if(ipsDict[IPaddr][1]==15):
					from subprocess import call
					call(["sudo","iptables","-A","INPUT","-s",IPaddr,"-j","DROP"])					
					#add IP to banned IPs dict
					blockedIPs[IPaddr] = 1

				else:
				#if the ip sent less then 15 SYNs during the last 60 seconds we continue to count his SYNs
					ipsDict[IPaddr][1] += 1
					#print ipsDict[IPaddr][1]


		else:
			ipsDict[IPaddr] = [currentAcceptTime,1]
			#print (ipsDict)



def is_blocked(ip):
    #simply check if the blockedIp dict contains the IP
    return (ip in blockedIPs)


def main():
    sniff(prn=on_packet)


if __name__ == '__main__':
    main()
